// src/ai/utils/adminMessageSync.js
const prisma = require('../../lib/prisma.js');
const { parseSenderIdentity } = require('../../lib/utils.js');

// Track pesan yang dikirim BOT agar tidak double-save
const BOT_SENT_CACHE = new Map();
const BOT_SENT_TTL = 10000; // 10 detik cukup untuk dedup

function markBotMessage(recipientNumber, text) {
    const key = `${recipientNumber}::${text.substring(0, 50)}`;
    BOT_SENT_CACHE.set(key, Date.now());

    setTimeout(() => {
        BOT_SENT_CACHE.delete(key);
    }, BOT_SENT_TTL);
}

function isBotMessage(recipientNumber, text) {
    const key = `${recipientNumber}::${text.substring(0, 50)}`;
    return BOT_SENT_CACHE.has(key);
}

/**
 * Helper: Save message to SQL (Prisma)
 */
async function saveMessageToPrismaLocal(recipientNumber, messageText, senderType) {
    const { docId: phone } = parseSenderIdentity(recipientNumber);
    if (!phone) return;

    try {
        await prisma.directMessage.create({
            data: {
                customerId: phone,
                senderId: senderType === 'admin' ? 'admin' : 'assistant',
                role: senderType === 'admin' ? 'user' : 'assistant', // In SQL, admin is represented as user-role for now or just 'admin'
                content: messageText,
                createdAt: new Date()
            }
        });

        await prisma.customer.update({
            where: { id: phone },
            data: {
                lastMessage: messageText,
                lastMessageAt: new Date(),
                updatedAt: new Date()
            }
        }).catch(() => {}); // Ignore if customer not exists yet

    } catch (error) {
        console.error(`Error saving ${senderType} message to SQL:`, error);
    }
}

async function handleAdminHpMessage(msg) {
    if (!msg.fromMe) return;
    if (msg.from === 'status@broadcast') return;

    const messageText = (msg.body || msg.caption || '').trim();
    if (!messageText) return;

    const recipientNumber = msg.to;
    if (!recipientNumber) return;

    if (isBotMessage(recipientNumber, messageText)) {
        console.log(`[AdminSync] Skip bot message to ${recipientNumber}`);
        return;
    }

    try {
        await saveMessageToPrismaLocal(recipientNumber, messageText, 'admin');
        console.log(`[AdminSync] ✅ Synced admin HP message to ${recipientNumber}: "${messageText.substring(0, 50)}"`);

        const { setSnoozeMode, isSnoozeActive } = require('./humanHandover.js');
        const { normalizedAddress } = parseSenderIdentity(recipientNumber);

        const snoozeActive = await isSnoozeActive(normalizedAddress);
        if (!snoozeActive) {
            await setSnoozeMode(normalizedAddress, 60, {
                manual: false,
                reason: 'admin-replied-from-phone',
            });
            console.log(`[AdminSync] Auto-snooze activated for ${recipientNumber} (admin replied from HP)`);
        }

    } catch (error) {
        console.error(`[AdminSync] Error syncing message:`, error.message);
    }
}

module.exports = { handleAdminHpMessage, markBotMessage };
