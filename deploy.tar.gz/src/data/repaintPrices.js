// File: src/data/repaintPrices.js
// Data harga repaint spesifik per model motor.
// Source: src/data/daftarHargaRepaint.md (Update Februari 2026) dan daftarUkuranMotor.js

/**
 * Struktur:
 *   aliases   – array keyword agar fuzzy-match lebih mudah
 *   price     – harga tetap (number)
 *   note      – keterangan tambahan
 *   category  – sub-kategori repaint (bodi_halus | bodi_kasar | velg | warna_spesial)
 *   brand     – brand motor
 */

const repaintBodiHalus = [
    // ─── BODY 1: Matic Kecil & Bebek ───
    { model: "scoopy", aliases: ["honda scoopy", "scoopy prestige", "scoopy sporty", "scoopy stylish", "scoopy fi", "scoopy injection"], price: 1500000, note: "Full Body Halus", brand: "honda" },
    { model: "genio", aliases: ["honda genio"], price: 1500000, note: "Full Body Halus", brand: "honda" },
    { model: "fino", aliases: ["yamaha fino"], price: 1500000, note: "Full Body Halus", brand: "yamaha" },
    { model: "fazzio", aliases: ["yamaha fazzio", "fazio", "grand filano", "filano"], price: 1500000, note: "Full Body Halus", brand: "yamaha" },
    { model: "nouvo", aliases: ["yamaha nouvo", "nouvo z", "nouvo elegance"], price: 1200000, note: "Full Body Halus", brand: "yamaha" },
    { model: "vario 110", aliases: ["honda vario 110", "vario karbu", "vario techno 110"], price: 900000, note: "Full Body Halus", brand: "honda" },
    { model: "vario 125/150/160", aliases: ["honda vario", "vario 125", "vario 150", "vario 160"], price: 1200000, note: "Full Body Halus", brand: "honda" },
    { model: "mio", aliases: ["yamaha mio", "mio sporty", "mio j", "mio m3"], price: 800000, note: "Full Body Halus", brand: "yamaha" },
    { model: "xeon", aliases: ["yamaha xeon", "xeon rc", "xeon gt"], price: 800000, note: "Full Body Halus", brand: "yamaha" },
    { model: "beat", aliases: ["honda beat", "beat pop", "beat street"], price: 800000, note: "Full Body Halus", brand: "honda" },
    { model: "nex", aliases: ["suzuki nex", "nex ii"], price: 800000, note: "Full Body Halus", brand: "suzuki" },
    { model: "spacy", aliases: ["honda spacy"], price: 800000, note: "Full Body Halus", brand: "honda" },
    { model: "gear", aliases: ["yamaha gear", "gear 125"], price: 800000, note: "Full Body Halus", brand: "yamaha" },
    { model: "spin", aliases: ["suzuki spin", "spin 125"], price: 800000, note: "Full Body Halus", brand: "suzuki" },
    { model: "vega", aliases: ["yamaha vega", "vega r", "vega zr"], price: 800000, note: "Full Body Halus", brand: "yamaha" },
    { model: "smash", aliases: ["suzuki smash"], price: 800000, note: "Full Body Halus", brand: "suzuki" },
    { model: "x-ride", aliases: ["yamaha x-ride", "xride"], price: 800000, note: "Full Body Halus", brand: "yamaha" },
    { model: "freego", aliases: ["yamaha freego"], price: 800000, note: "Full Body Halus", brand: "yamaha" },
    { model: "skydrive", aliases: ["suzuki skydrive"], price: 800000, note: "Full Body Halus", brand: "suzuki" },
    { model: "hayate", aliases: ["suzuki hayate"], price: 800000, note: "Full Body Halus", brand: "suzuki" },
    { model: "supra", aliases: ["honda supra", "supra x", "supra fit"], price: 800000, note: "Full Body Halus", brand: "honda" },
    { model: "revo", aliases: ["honda revo", "revo absolute"], price: 800000, note: "Full Body Halus", brand: "honda" },
    { model: "blade", aliases: ["honda blade"], price: 800000, note: "Full Body Halus", brand: "honda" },
    { model: "address", aliases: ["suzuki address"], price: 800000, note: "Full Body Halus", brand: "suzuki" },
    { model: "shogun", aliases: ["suzuki shogun"], price: 800000, note: "Full Body Halus", brand: "suzuki" },
    { model: "skywave", aliases: ["suzuki skywave"], price: 800000, note: "Full Body Halus", brand: "suzuki" },
    { model: "polytron evo", aliases: ["polytron fox"], price: 850000, note: "Full Body Halus", brand: "ev" },
    { model: "selis e-max", aliases: ["selis emax"], price: 850000, note: "Full Body Halus", brand: "ev" },
    { model: "smoot tempur", aliases: ["smoot"], price: 850000, note: "Full Body Halus", brand: "ev" },
    { model: "jupiter z", aliases: ["yamaha jupiter z", "jupiter"], price: 800000, note: "Full Body Halus", brand: "yamaha" },
    { model: "soul gt", aliases: ["yamaha soul gt"], price: 800000, note: "Full Body Halus", brand: "yamaha" },

    // ─── BODY 2: Matic Besar & Bebek Super ───
    { model: "nmax", aliases: ["yamaha nmax", "n-max"], price: 1200000, note: "Full Body Halus", brand: "yamaha" },
    { model: "pcx", aliases: ["honda pcx", "pcx 150", "pcx 160"], price: 1500000, note: "Full Body Halus", brand: "honda" },
    { model: "adv", aliases: ["honda adv", "adv 150", "adv 160"], price: 1500000, note: "Full Body Halus", brand: "honda" },
    { model: "aerox", aliases: ["yamaha aerox"], price: 1000000, note: "Full Body Halus", brand: "yamaha" },
    { model: "satria fu", aliases: ["suzuki satria f150", "satria f"], price: 1000000, note: "Full Body Halus", brand: "suzuki" },
    { model: "mx king", aliases: ["yamaha mx king", "mx king 150"], price: 800000, note: "Full Body Halus", brand: "yamaha" },
    { model: "lexi", aliases: ["yamaha lexi"], price: 800000, note: "Full Body Halus", brand: "yamaha" },
    { model: "jupiter mx", aliases: ["yamaha jupiter mx", "mx 135"], price: 800000, note: "Full Body Halus", brand: "yamaha" },
    { model: "vespa", aliases: ["vespa lx", "vespa s", "vespa sprint", "vespa primavera", "vespa gts", "vespa klasik", "vespa px"], price: 2500000, note: "Full Body Halus", brand: "vespa" },
    { model: "sonic", aliases: ["honda sonic", "sonic 150r"], price: 800000, note: "Full Body Halus", brand: "honda" },
    { model: "supra gtr 150", aliases: ["honda supra gtr", "gtr 150"], price: 800000, note: "Full Body Halus", brand: "honda" },
    { model: "gesits", aliases: ["gesits g1"], price: 1020000, note: "Full Body Halus", brand: "ev" },
    { model: "alva one", aliases: ["alva"], price: 1275000, note: "Full Body Halus", brand: "ev" },
    { model: "alva cervo", aliases: [], price: 1275000, note: "Full Body Halus", brand: "ev" },
    { model: "united t1800", aliases: ["united"], price: 1360000, note: "Full Body Halus", brand: "ev" },
    { model: "polytron t-rex", aliases: ["polytron fox r"], price: 1275000, note: "Full Body Halus", brand: "ev" },
    { model: "viar e-cross", aliases: ["viar ecross"], price: 1100000, note: "Full Body Halus", brand: "ev" },
    { model: "w175", aliases: ["kawasaki w175"], price: 1100000, note: "Full Body Halus", brand: "kawasaki" },

    // ─── BODY 3: Sport & Fairing ───
    { model: "cbr", aliases: ["honda cbr", "cbr 150r", "cbr150r", "cbr 250rr", "cbr250rr"], price: 1500000, note: "Full Body Halus", brand: "honda" },
    { model: "vixion", aliases: ["yamaha vixion", "v-ixion"], price: 1500000, note: "Full Body Halus", brand: "yamaha" },
    { model: "r15", aliases: ["yamaha r15"], price: 1500000, note: "Full Body Halus", brand: "yamaha" },
    { model: "r25", aliases: ["yamaha r25"], price: 1500000, note: "Full Body Halus", brand: "yamaha" },
    { model: "mt-15", aliases: ["yamaha mt-15", "mt15"], price: 1600000, note: "Full Body Halus", brand: "yamaha" },
    { model: "mt-25", aliases: ["yamaha mt-25", "mt25"], price: 1600000, note: "Full Body Halus", brand: "yamaha" },
    { model: "xabre", aliases: ["yamaha xabre"], price: 1600000, note: "Full Body Halus", brand: "yamaha" },
    { model: "gsx-r150", aliases: ["suzuki gsx-r150", "gsxr150"], price: 1800000, note: "Full Body Halus", brand: "suzuki" },
    { model: "gsx-s150", aliases: ["suzuki gsx-s150", "gsxs150"], price: 1800000, note: "Full Body Halus", brand: "suzuki" },
    { model: "ninja", aliases: ["kawasaki ninja", "ninja 250", "ninja fi", "ninja karbu", "ninja 250 sl", "ninja rr mono", "zx25r"], price: 1800000, note: "Full Body Halus", brand: "kawasaki" },
    { model: "tiger", aliases: ["honda tiger", "tiger revo", "gl pro", "gl max"], price: 1800000, note: "Full Body Halus (Termasuk Tangki)", brand: "honda" },
    { model: "thunder 125", aliases: ["suzuki thunder"], price: 1800000, note: "Full Body Halus (Termasuk Tangki)", brand: "suzuki" },
    { model: "xsr 155", aliases: ["yamaha xsr"], price: 1800000, note: "Full Body Halus", brand: "yamaha" },
    { model: "cb 150r", aliases: ["honda cb 150r", "cb150r", "cb150 streetfire"], price: 1300000, note: "Full Body Halus", brand: "honda" },
    { model: "verza", aliases: ["honda verza", "cb150 verza"], price: 1300000, note: "Full Body Halus", brand: "honda" },
    { model: "megapro", aliases: ["honda megapro", "mega pro"], price: 1500000, note: "Full Body Halus", brand: "honda" },
    { model: "byson", aliases: ["yamaha byson"], price: 1200000, note: "Full Body Halus", brand: "yamaha" },
    { model: "rx-king", aliases: ["yamaha rx-king", "rx king"], price: 2500000, note: "Full Body Restorasi", brand: "yamaha" },
    { model: "f1zr", aliases: ["fizr", "yamaha f1zr"], price: 2125000, note: "Full Body Restorasi", brand: "yamaha" },
    { model: "c70", aliases: ["honda pitung", "bekjul"], price: 1700000, note: "Restorasi Klasik", brand: "honda" },
    { model: "cb 100", aliases: ["cb gelatik", "honda cb"], price: 1700000, note: "Restorasi Klasik", brand: "honda" },
    { model: "astrea grand", aliases: ["honda grand", "bulus"], price: 1000000, note: "Restorasi Bodi", brand: "honda" },
    { model: "win 100", aliases: ["honda win"], price: 1500000, note: "Restorasi Bodi", brand: "honda" },

    // ─── MOGE & OTHERS ───
    { model: "ninja 650", aliases: ["kawasaki ninja 650"], price: 2500000, note: "Full Body Halus (Moge)", brand: "kawasaki" },
    { model: "z650", aliases: ["kawasaki z650"], price: 2500000, note: "Full Body Halus (Moge)", brand: "kawasaki" },
    { model: "z900", aliases: ["kawasaki z900"], price: 3000000, note: "Full Body Halus (Moge)", brand: "kawasaki" },
    { model: "z1000", aliases: ["kawasaki z1000"], price: 3500000, note: "Full Body Halus (Moge)", brand: "kawasaki" },
    { model: "harley street 500", aliases: ["harley davidson"], price: 3500000, note: "Full Body Halus (Moge)", brand: "harley" },
    { model: "bmw g310r", aliases: ["g310r"], price: 3000000, note: "Full Body Halus (Moge)", brand: "bmw" },
];

// ─── REPAINT BODI KASAR ───
const repaintBodiKasar = [
    { category: "Small Matic / Bebek", price: 300000, examples: "Beat, Mio, Supra" },
    { category: "Medium Matic", price: 380000, examples: "Scoopy, Vario" },
    { category: "Big Matic", price: 510000, examples: "NMax, PCX, ADV" },
    { category: "Extra Big Matic", price: 765000, examples: "XMAX, Forza" },
];

// ─── REPAINT VELG ───
const repaintVelg = [
    { category: "Matic Kecil / Bebek", price: 350000, note: "Ring 14 / 17 (Scoopy, Beat, Vario, dll)" },
    { category: "Big Matic / Super Bebek", price: 400000, note: "Velg Lebar (NMax, PCX, Aerox, Satria FU, MX King)" },
    { category: "Sport 150cc - 250cc", price: 450000, note: "Velg Lebar (CBR, Ninja, GSX, Vixion)" },
];

// Helper maps untuk Velg (memasukkan data fix dari user)
const VELG_PRICE_MAP = {
    // 350k tier
    "scoopy": 350000, "genio": 350000, "vario": 350000, "mio": 350000, "beat": 350000, "vega": 350000, "fino": 350000,
    "nouvo": 350000, "smash": 350000, "fazzio": 350000, "x-ride": 350000, "nex": 350000, "spacy": 350000, "gear": 350000,
    "freego": 350000, "xeon": 350000, "skydrive": 350000, "spin": 350000, "hayate": 350000,
    // 400k tier
    "nmax": 400000, "mx king": 400000, "satria fu": 400000, "pcx": 400000, "adv": 400000, "aerox": 400000, "fizr": 400000,
    "lexi": 400000, "jupiter": 400000, "vespa": 400000, "revo": 400000, "sonic": 400000, "blade": 400000,
    // 450k tier
    "cbr": 450000, "gsx": 450000, "vixion": 450000, "byson": 450000, "tiger": 450000, "rx king": 450000, "thunder": 450000,
    "xsr": 450000, "r15": 450000, "r25": 450000, "ninja": 450000, "cb 150": 450000, "megapro": 450000, "mt": 450000, "xabre": 450000
};

// ─── TAMBAHAN WARNA SPESIAL ───
const warnaSpesial = [
    { type: "Candy Colors", aliases: ["candy", "candy red", "candy blue", "candy tone"], surcharge: 125000 },
    { type: "Stabilo (Fluo)", aliases: ["stabilo", "fluo", "fluorescent"], surcharge: 170000 },
    { type: "Two-Tone / Polish", aliases: ["twotone", "polished", "velg polish"], surcharge: 210000 },
    { type: "Bunglon", aliases: ["cameleon", "chameleon"], surcharge: 300000 },
    { type: "Chrome / Hologram", aliases: ["chrome", "kroom", "hologram"], surcharge: 500000 },
];

// ─── SYARAT & KETENTUAN ───
const syaratKetentuan = [
    "Harga di atas adalah harga FIX untuk Body Halus.",
    "Harga belum termasuk Body Kasar.",
    "Harga belum termasuk Pretelan/Aksesoris.",
    "Harga bisa berubah sesuai kondisi Body/Motor (lecet parah/pecah).",
    "Untuk warna Bunglon, Hologram, atau Chrome, harga melalui kesepakatan khusus.",
    "Harga Velg belum termasuk tambahan CAT Behel/Arm/Shock (+50rb) atau CVT (+100rb).",
    "Biaya Remover Velg (bekas cat/jamur) +50rb s/d 100rb.",
];

module.exports = {
    repaintBodiHalus,
    repaintBodiKasar,
    repaintVelg,
    warnaSpesial,
    syaratKetentuan,
    VELG_PRICE_MAP,
};
